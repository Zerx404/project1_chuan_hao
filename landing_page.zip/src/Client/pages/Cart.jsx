export default function Cart() {
  return (
    <div style={{ padding: 24 }}>
      <h1>Giỏ hàng</h1>
      <p>Chưa có sản phẩm nào</p>
    </div>
  );
}
