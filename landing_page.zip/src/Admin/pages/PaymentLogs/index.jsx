export default function PaymentLogs() {
  return <h1>Payment Logs</h1>;
}
