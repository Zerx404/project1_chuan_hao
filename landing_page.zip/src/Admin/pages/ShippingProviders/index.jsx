export default function ShippingProviders() {
  return <h1>Shipping Providers</h1>;
}
