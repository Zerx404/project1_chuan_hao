export default function Orders() {
  return <h1>Orders</h1>;
}
