export default function UserAddresses() {
  return <h1>User Addresses</h1>;
}
